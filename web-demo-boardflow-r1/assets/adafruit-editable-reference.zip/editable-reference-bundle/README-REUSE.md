# 可编辑参考工程（非客户量产设计）

- 来源：Adafruit Industries, https://github.com/adafruit/Adafruit-Feather-ESP32-S3-PCB/tree/2c95ed51a500d929fd6d8f519b895f0c4daeb982
- 原生文件：`source-eagle/Adafruit ESP32-S3 8MB No PSRAM.sch` 与 `.brd`，逐字节复制。
- 许可证：原仓库 `source-eagle/README.md`、`source-eagle/license.txt`；硬件以 CC-BY-SA-3.0-Unported 标识。复用与再发布需保留署名及相应义务；正式合规待另审。
- 转换工程：`Adafruit-Feather-ESP32-S3-8MB-No-PSRAM-Eagle/Adafruit-Feather-ESP32-S3-8MB-No-PSRAM-Eagle.eprj3`。在嘉立创EDA专业版 V4.1.71 的 EAGLE 导入功能生成，可编辑的原理图与 PCB 均曾在客户端打开。
- 这是 Adafruit Feather ESP32-S3 **8MB No PSRAM** 参考板，非客户 N16R8 目标；含 U4 BME280、X3 USB-C。原设计本身不构成目标板电气/制造批准。
- 导入客户端报告 6 条电源符号引脚编号自动修复或去重警告；PCB 打开后另有“存在未填充的铺铜图元，建议在铺铜管理器进行重建。”。网表、ERC、PCB DRC、Gerber、BOM、实物均未在本包证明通过。
- 参考图：同级审计目录 `schematic-export.png`、`pcb-export.png`。证据和详细范围见同级报告。
